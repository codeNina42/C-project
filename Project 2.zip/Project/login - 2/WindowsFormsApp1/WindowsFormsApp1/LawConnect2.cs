﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LawConnect2 : Form
    {
        public LawConnect2()
        {
            InitializeComponent();
            this.Width = 900;
            this.Height = 425;
        }

        private void LawConnect2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "data source=DESKTOP-4QU6BBP\\SQLEXPRESS; database=Project; integrated security=SSPI";

            string id = textBox1.Text.Trim();
            string name = textBox2.Text.Trim();
            string phone_number = textBox3.Text.Trim();
            string age = textBox4.Text.Trim();
            string password = textBox5.Text.Trim();
            string pin = textBox6.Text.Trim();

            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(name) ||
                string.IsNullOrWhiteSpace(age) || string.IsNullOrWhiteSpace(phone_number) ||string.IsNullOrWhiteSpace(pin) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("All fields must be filled out.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(age, out int parsedAge))
            {
                MessageBox.Show("Age must be a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(id, out int userIdInt))
            {
                MessageBox.Show("ID should be a numeric value.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            } 
            if (!int.TryParse(pin, out int userpPinInt) || pin.Length != 4)
            {
                MessageBox.Show("Pin should be a numeric value(Exactly 4 digits).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM Client WHERE Cl_id = @Cl_id";              // this  is for checking if the ID already exists

                using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@Cl_id", id);
                    int count = (int)checkCommand.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("The ID already exists. Please choose a different ID.", "Duplicate ID Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }


                string query = "INSERT INTO Client (Cl_id, C_name, C_num, C_age, C_Password,Pin) VALUES (@Cl_id, @C_name, @C_num, @C_age, @C_Password,@Pin)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Cl_id", id);
                    command.Parameters.AddWithValue("@C_name", name);
                    command.Parameters.AddWithValue("@C_num", phone_number);
                    command.Parameters.AddWithValue("@C_age", parsedAge);
                    command.Parameters.AddWithValue("@C_Password", password);
                    command.Parameters.AddWithValue("@Pin", pin);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Profile created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        LawConnect1 f1 = new LawConnect1();
                        f1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Failed to create the profile. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            LawConnect1 f1 = new LawConnect1();
            f1.Show();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
